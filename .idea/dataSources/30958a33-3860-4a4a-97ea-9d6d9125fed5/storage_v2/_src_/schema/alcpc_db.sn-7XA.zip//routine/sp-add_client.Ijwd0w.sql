create
    definer = root@localhost procedure `sp-add_client`(IN _company_name varchar(100), IN _company_owner varchar(100),
                                                       IN _streetno_bldg varchar(100), IN _towncity varchar(100),
                                                       IN _province varchar(100), IN _barangay varchar(100),
                                                       IN _region varchar(100), IN _email_add varchar(50),
                                                       IN _mob_no varchar(50), IN _tel_no varchar(50),
                                                       IN _ass_fsa varchar(50), IN _biz_style varchar(50),
                                                       IN _remarks text, IN _added_by varchar(50))
BEGIN

    # check for duplicate client
    #SELECT client_id INTO @is_duplicate_client FROM client_tbl WHERE UPPER(CONCAT(TRIM(company_name),TRIM(company_owner),TRIM(towncity),TRIM(province))) = UPPER(CONCAT(TRIM(_company_name),TRIM(_company_owner),TRIM(_towncity),TRIM(_province))) LIMIT 1;
    SELECT client_id INTO @is_duplicate_client FROM client_tbl WHERE company_name = _company_name LIMIT 1;

    IF(@is_duplicate_client IS NOT NULL) THEN
        SELECT
            @is_duplicate_client as 'is_duplicate_client'
        ;
    ELSE 
        INSERT INTO client_tbl (
            company_name,
            company_owner,
            streetno_bldg,
            towncity,
            province,
            barangay,
            region,
            email_add,
            mob_no,
            tel_no,
            ass_fsa,
            biz_style,
            remarks,
            c_status,
            enrollment_date,
            added_by
            
        )
        VALUES (
			_company_name,
			_company_owner,
			_streetno_bldg,
			_towncity,
			_province,
			_barangay,
			_region,
			_email_add,
			_mob_no,
			_tel_no,
			_ass_fsa,
			_biz_style,
			_remarks,
			1,
			now(),
			_added_by

        );
    END IF;

END;

