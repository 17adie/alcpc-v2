create
    definer = root@localhost procedure `sp-get_all_client_filterable`(IN _limit_offset int,
                                                                      IN _search_string varchar(255),
                                                                      IN _sort_direction enum ('asc', 'desc'),
                                                                      IN _sort_by varchar(255), OUT _total_count int)
BEGIN
	DECLARE search_string VARCHAR(255);
    
    SET search_string = CASE WHEN _search_string = '' THEN NULL ELSE TRIM(Replace(Replace(Replace(_search_string,'\t',''),'\n',''),'\r','')) END;
    
	SELECT SQL_CALC_FOUND_ROWS
	  c.client_id,
      c.company_name,
      c.company_owner,
      c.towncity,
      c.province,
      c.c_status,
      rbs.bussiness_style,
      CONCAT(rf.first_name, ' ' ,rf.last_name) as fsa
	FROM client_tbl c
    INNER JOIN ref_biz_style_tbl rbs ON c.biz_style = rbs.tbl_id
    INNER JOIN ref_fsa_tbl rf ON c.ass_fsa = rf.tbl_id
	WHERE 
		CASE WHEN search_string IS NULL THEN
			1 = 1
		ELSE
			CONCAT(client_id,company_name,company_owner) LIKE CONCAT('%',search_string,'%')
		END
        
    ORDER BY
      CASE WHEN _sort_direction = 'asc'
        THEN
          CASE _sort_by
          WHEN 'client_id' THEN client_id
          WHEN 'company_name' THEN company_name
          WHEN 'company_owner' THEN company_owner
          WHEN 'towncity' THEN towncity
          WHEN 'province' THEN province
		  WHEN 'bussiness_style' THEN bussiness_style
		  WHEN 'fsa' THEN fsa
          WHEN 'c_status' THEN c_status
          END
      END ASC,
      CASE WHEN _sort_direction = 'desc'
        THEN
          CASE _sort_by
		   WHEN 'client_id' THEN client_id
          WHEN 'company_name' THEN company_name
          WHEN 'company_owner' THEN company_owner
          WHEN 'towncity' THEN towncity
          WHEN 'province' THEN province
          WHEN 'bussiness_style' THEN bussiness_style
		  WHEN 'fsa' THEN fsa
          WHEN 'c_status' THEN c_status
          END
      END DESC
	LIMIT 10 OFFSET _limit_offset;
    
    SET _total_count = FOUND_ROWS();

END;

