create definer = root@localhost trigger client_tbl_BEFORE_INSERT
    before INSERT
    on client_tbl
    for each row
BEGIN

SELECT tbl_id + 1
	INTO @num
	FROM client_tbl
	ORDER BY tbl_id DESC LIMIT 1;
	#SET @num = new.tbl_id;
    #SET @num = 4321;
    SET @str = '';
    SELECT CHAR_LENGTH(@num)
    INTO @char_length;
    WHILE @char_length < 6 DO
      SET @str = CONCAT(@str, '0');
      SET @char_length = @char_length + 1;
    END WHILE;

    SET new.client_id = CONCAT('', @str, @num);

END;

